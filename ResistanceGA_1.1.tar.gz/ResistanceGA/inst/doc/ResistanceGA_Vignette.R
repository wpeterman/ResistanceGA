
## ----load.packages, echo = FALSE, message = FALSE------------------------
library(akima)
library(raster)
library(plyr)
library(GA)
library(lme4)
library(ggplot2)


## ----install.package, eval=FALSE-----------------------------------------
## # Install 'devtools' package, if needed
## if ("devtools" %in% rownames(installed.packages()) == FALSE) {
##     install.packages("devtools", repo = "http://cran.rstudio.com", dep = TRUE)
## }
## 
## library(devtools) # Loads devtools
## 
## install_github("wpeterman/ResistanceGA") # Download package


## ----results='hide',message=FALSE, warning=FALSE-------------------------
require(RandomFields)
require(ResistanceGA)

rm(list = ls())


## ----plot.trans.demo-----------------------------------------------------
Ricker.plot <- PLOT.trans(PARM=c(1.5, 200),Resistance=c(1,10),transformation="Ricker")

# Change title of plot
Ricker.plot$labels$title<-"Ricker Tansformation"
Ricker.plot

# Find original data value that now has maximum resistance
Ricker.plot$data$original[which(Ricker.plot$data$transformed==max(Ricker.plot$data$transformed))]


## ----warning=FALSE, results='hide',message=FALSE, eval=FALSE-------------
## 
## if("ResistanceGA_Examples"%in%dir("C:/")==FALSE)
##   dir.create(file.path("C:/", "ResistanceGA_Examples"))
## 
## # Create a subdirectory for the first example
## dir.create(file.path("C:/ResistanceGA_Examples/","SingleSurface"))
## 
## write.dir <- "C:/ResistanceGA_Examples/SingleSurface/"      # Directory to write .asc files and results


## ------------------------------------------------------------------------
r.dim <- 50       # number of cells on a side
cell.size <- 0.025        # raster cell dimension     
min.point <- 0.25*(r.dim*cell.size)       # minimum coordinate for generating random points (multiplied by 0.25 to prevent edge effects)
max.point <- (r.dim*cell.size)-min.point        # maximum coordinate for generating random points

# Number of "Sample locations" to generate. This example will generate points on a square grid, so choose a number that has an even square root
n <- 25 
x <- seq(from=min.point,max.point, length.out=5) + (cell.size/2)       # set x & y locations for points
y <- seq(from=min.point,max.point, length.out=5) + (cell.size/2)  
Sample.points<-expand.grid(x,y)

Sample.coord <- SpatialPoints(Sample.points)
coord.id <- cbind((1:n),Sample.coord@coords)       # Combine location ID with coordinates


## ----eval=FALSE----------------------------------------------------------
## write.table(coord.id,file=paste0(write.dir,"samples.txt"),sep="\t",col.names=F,row.names=F)


## ----single.surface, warning=FALSE, results='hide',message=FALSE---------
set.seed(12345)
model <- RMexp() +
  RMtrend(mean=10)

grid.vars <- GridTopology(cellcentre.offset=c(cell.size/2, cell.size/2),
                          cellsize=c(cell.size, cell.size),
                          cells.dim=rep(r.dim,2))

rf.sim <- RFsimulate(model, x=grid.vars)

cont.rf <- raster(rf.sim[1]) # Define object as a continuous raster surface
names(cont.rf)<-"cont"


## ----single.surface.plot-------------------------------------------------
plot(cont.rf)
plot(Sample.coord, pch=16, col="blue", add=TRUE) # Add points


## ----message=FALSE,results='hide',eval=FALSE-----------------------------
## writeRaster(cont.rf,filename=paste0(write.dir,"cont.asc"),overwrite=TRUE)


## ----eval=FALSE----------------------------------------------------------
## # Set the random number seed to reproduce the results presented
## GA.inputs <- GA.prep(ASCII.dir=write.dir,
##                    min.cat=0,
##                    max.cat=500,
##                    max.cont=500,
##                    seed = 99)
## 
## CS.inputs <- CS.prep(n.POPS=n,
##                    CS_Point.File=paste0(write.dir,"samples.txt"),
##                    CS.exe=paste('"C:/Program Files/Circuitscape/4.0/cs_run.exe"'))


## ----monomolec.plot------------------------------------------------------
r.tran <- Resistance.tran(transformation="Monomolecular", shape=2, max=275, r=cont.rf) 

plot.t <- PLOT.trans(PARM=c(2,275), Resistance="C:/ResistanceGA_Examples/SingleSurface/cont.asc", transformation="Monomolecular") 


## ----echo=FALSE, eval=FALSE----------------------------------------------
## # Create the true resistance/response surface
## CS.response <- Run_CS(CS.inputs=CS.inputs,GA.inputs=GA.inputs, r=r.tran)
## 
## # Write CS.response to file for use with optimization
## write.table(CS.response,paste0(write.dir,"CS.response.txt"),col.names=F,row.names=F)


## ----eval=FALSE----------------------------------------------------------
## CS.inputs <- CS.prep(n.POPS=n,
##                    RESPONSE=CS.response,
##                    CS_Point.File=paste0(write.dir,"samples.txt"),
##                    CS.exe=paste('"C:/Program Files/Circuitscape/4.0/cs_run.exe"'))


## ----eval=FALSE----------------------------------------------------------
## SS_RESULTS <- SS_optim(CS.inputs=CS.inputs,
##                        GA.inputs=GA.inputs)


## ----eval=FALSE----------------------------------------------------------
## Grid.Results <- Grid.Search(shape=seq(1,4,by=0.1),max=seq(50,500,by=75),transformation="Monomolecular",Resistance=cont.rf, CS.inputs)


## ----warning=FALSE, results='hide',message=FALSE, eval=FALSE-------------
## set.seed(321)
## if("ResistanceGA_Examples"%in%dir("C:/")==FALSE)
##   dir.create(file.path("C:/", "ResistanceGA_Examples"))
## 
## # Create a subdirectory for the second example
## dir.create(file.path("C:/ResistanceGA_Examples/","MultipleSurfaces"))
## 
## write.dir <- "C:/ResistanceGA_Examples/MultipleSurfaces/"      # Directory to write .asc files and results


## ----multi_surface.sim, warning=FALSE, message=FALSE,results='hide'------
rf.sim <- RFsimulate(model, x=grid.vars,n=2) # Create two surfaces

cont.rf <- raster(rf.sim[1]) # Define first as a continuous surface
names(cont.rf)<-"cont"

plot(cont.rf)
plot(Sample.coord, pch=16, col="blue", add=TRUE)

cat.rf <- raster(rf.sim[2]) 
names(cat.rf) <- "cat"
cat.cut <- summary(cat.rf) # Define quartiles, use these to define categories

cat.rf[cat.rf<=cat.cut[2]] <- 0
cat.rf[cat.rf>0 & cat.rf<=cat.cut[4]] <- 1
cat.rf[!cat.rf%in%c(0,1)] <- 2
plot(cat.rf)
plot(Sample.coord, pch=16, col="blue", add=TRUE)


## ----feature.sim, warning=FALSE,message=FALSE----------------------------
feature <- matrix(0,r.dim,r.dim)
feature[23,] <- 1
feature[,22:24] <- 1
feature <- raster(feature)
extent(feature)<-extent(cat.rf)
plot(feature)
names(feature)<-"feature"
plot(feature)
plot(Sample.coord, pch=16, col="blue", add=TRUE)


## ----write_multi.ASCII, warning=FALSE, results='hide',message=FALSE,eval=FALSE----
## writeRaster(cat.rf,filename=paste0(write.dir,"cat.asc"),overwrite=TRUE)
## writeRaster(cont.rf,filename=paste0(write.dir,"cont.asc"),overwrite=TRUE)
## writeRaster(feature,filename=paste0(write.dir,"feature.asc"),overwrite=TRUE)
## 
## write.table(coord.id,file=paste0(write.dir,"samples.txt"),sep="\t",col.names=F,row.names=F)


## ----eval=FALSE----------------------------------------------------------
## GA.inputs <- GA.prep(ASCII.dir=write.dir,
##                    min.cat=0,
##                    max.cat=500,
##                    max.cont=500,
##                    seed = 99)


## ----inverse-reverse.mono, eval=FALSE------------------------------------
## plot.t <- PLOT.trans(PARM=c(2,250),Resistance="C:/ResistanceGA_Examples/MultipleSurfaces/cont.asc",transformation="Inverse-Reverse Monomolecular")


## ----combine.surfaces,eval=FALSE-----------------------------------------
## PARM <- c(0,150,50,1,2,250,0,400)
## 
## # PARM<- c(0,   # First feature of categorical
## #        150, # Second feature of categorical
## #        50,  # Third feature of categorical
## #        1,   # Transformation equation for continuous surface
## #        2,   # Shape parameter
## #        250, # Scale parameter
## #        0,   # First feature of feature surface
## #        400) # Second feature of feature surface
## 
## # Combine resistance surfaces
## Resist <- Combine_Surfaces(PARM=PARM,CS.inputs=CS.inputs,GA.inputs=GA.inputs,out=NULL)
## 
## # View combined surface
## plot(Resist)


## ----combine.cs,eval=FALSE-----------------------------------------------
## # Create the true resistance/response surface
## CS.Resist <- Run_CS(CS.inputs=CS.inputs,GA.inputs=GA.inputs,r=Resist)
## 
## NOISE <- rnorm(n=length(CS.Resist), mean=0,(0.015*max(CS.Resist)))
## 
## CS.response <- CS.Resist + NOISE
## plot(CS.response~CS.Resist)
## 
## # Write the response to a file
## write.table(CS.response,file=paste0(write.dir,"Combined_response.csv"),sep=",",row.names=F,col.names=F)


## ----eval=FALSE----------------------------------------------------------
## CS.inputs<-CS.prep(n.POPS=n,
##                       RESPONSE=CS.response,
##                       CS_Point.File=paste0(write.dir,"samples.txt"),
##                       CS.exe=paste('"C:/Program Files/Circuitscape/4.0/cs_run.exe"'))


## ----eval=FALSE----------------------------------------------------------
## Multi.Surface_optim <- MS_optim(CS.inputs=CS.inputs,
##                                GA.inputs=GA.inputs)


## ----eval=FALSE----------------------------------------------------------
## Multi.Surface_optim@solution # Optimized values
## 
## Optimized values for each surface:
## 1 85.45554 28.51652 1.75012 1.831599 151.6633  1 225.7778
## 
## # Simulated values
## PARM
## [1]   0 150  50   1   2 250   0 400


## ----combined.plots,fig.width=12,fig.height=8,eval=FALSE-----------------
## # Make combined, optimized resistance surface.
## # This could also be read in from the results directory
## optim.resist <- Combine_Surfaces(PARM=c(1, 85.45554, 28.51652, 1.75012, 1.831599, 151.6633,  1, 225.7778),CS.inputs,GA.inputs)
## ms.stack <- stack(Resist, optim.resist)
## plot(ms.stack, main=c("True Resistance", "Optimized Resistance")) # Optimized


## ----correlation.plot, eval=FALSE----------------------------------------
## # Correlation between the two surfaces
## names(ms.stack) <- c("Truth", "Optimized")
## pairs(ms.stack)


